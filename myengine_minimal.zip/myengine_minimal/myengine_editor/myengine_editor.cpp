#include "appbase.h"

using namespace myengine;

class App : public AppBase
{
};

int main()
{
    App app;
    return app.main("myengine", { 1280, 720 }, _PROJECT_NAME);
}