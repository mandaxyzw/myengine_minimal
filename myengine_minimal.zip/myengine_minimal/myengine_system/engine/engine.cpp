#include "engine.h"

#include "texture.h"

//****************************************************************************************************
// Vulkan
//****************************************************************************************************

void check_alignment(void *block, size_t alignment) {
    size_t x = ((size_t)block) % alignment;
    if (x != 0) {
        myengine_error((std::string("Not ") + std::to_string(alignment) + " bytes aligned.").c_str());
    }
}

static void* VKAPI_PTR vk_allocation(void *pUserData, size_t size, size_t alignment, VkSystemAllocationScope allocationScope)
{
    void *mem = malloc(size);
    check_alignment(mem, alignment);
    return mem;
}

static void* VKAPI_PTR vk_reallocation(void *pUserData, void *pOriginal, size_t size, size_t alignment, VkSystemAllocationScope allocationScope)
{
    void *mem = realloc(pOriginal, size);
    check_alignment(mem, alignment);
    return mem;
}

static void VKAPI_PTR vk_free(void *pUserData, void *pMemory)
{
    free(pMemory);
}

VkAllocationCallbacks* vk_getAllocationCallBacks_ptr()
{
    static VkAllocationCallbacks callbacks = {};
    callbacks.pUserData = nullptr;
    callbacks.pfnAllocation = vk_allocation;
    callbacks.pfnReallocation = vk_reallocation;
    callbacks.pfnFree = vk_free;
    callbacks.pfnInternalAllocation = nullptr;
    callbacks.pfnInternalFree = nullptr;
    return &callbacks;
}


//****************************************************************************************************
// CopyCommandBuffer
// Referenced from "examples/imgui/main.cpp" > initResources in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
//****************************************************************************************************

myengine::CopyCommandBuffer::CopyCommandBuffer(Engine *engine) {
    _engine = engine;
    _isBegan = false;
    _vk_copyCmd = nullptr;
}
void myengine::CopyCommandBuffer::begin() {
    assert(!_isBegan);
    _isBegan = true;
    _vk_copyCmd = _engine->_vk._vulkanDevice->createCommandBuffer(VK_COMMAND_BUFFER_LEVEL_PRIMARY, true);
}
void myengine::CopyCommandBuffer::end() {
    assert(_isBegan);
    _isBegan = false;
    _engine->_vk._vulkanDevice->flushCommandBuffer(_vk_copyCmd, _engine->_vk._copyQueue, true);
}


//****************************************************************************************************
// Engine
//****************************************************************************************************

myengine::Engine::Engine(const char *projectName, VkPhysicalDevice physicalDevice, VkDevice device, uint32_t queueFamily, VkQueue copyQueue, bool useStagingBuffer)
{
    _projectName          = projectName;
    _copyCmd              = new myengine::CopyCommandBuffer(this);

    //----------

    // DRAFT for myengine::Compute (10/30/2021)
    //{
    //    // Referenced from "vulkanexamplebase.cpp" > initVulkan in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
    //
    //    _vk._enabledFeatures = {};
    //    _vk._enabledDeviceExtensions.clear();
    //    _vk._enabledInstanceExtensions.clear();
    //    _vk._deviceCreatepNextChain = nullptr;
    //
    //    _vk._vulkanDevice = new vks::VulkanDevice(physicalDevice);
    //    VkResult result = _vk._vulkanDevice->createLogicalDevice(_vk._enabledFeatures, _vk._enabledDeviceExtensions, _vk._deviceCreatepNextChain);
    //    if (result != VK_SUCCESS) {
    //        myengine_error_exit((std::string("Could not create Vulkan device: \n") + vks::tools::errorString(result)).c_str());
    //    }
    //}
    {
        _vk._vulkanDevice = new vks::VulkanDevice(physicalDevice);
        _vk._vulkanDevice->logicalDevice = device;

        // We have to create a command pool before we can create command buffers. Command pools manage the memory that is used to store the buffers and command buffers are allocated from them.
        // Add a new class member to store a VkCommandPool https://vulkan-tutorial.com/Drawing_a_triangle/Drawing/Command_buffers
        _vk._vulkanDevice->commandPool = _vk._vulkanDevice->createCommandPool(queueFamily);
    }
    _vk._copyQueue        = copyQueue;
    _vk._useStagingBuffer = useStagingBuffer;
    {
        // memset(..., 0, sizeof(*...)); Don't do it because there can be member variables that shouldn't be set to zero (hint: std::vector).
        TextureCreateInfo textureCI = {};
        textureCI.type = TextureCreateInfoType_None;
        _vk._staging_texture = new Texture(this, nullptr, textureCI); // TODO: Unfinished work, the command buffer is nullptr.
    }

    //----------

    {
        // memset(..., 0, sizeof(*...)); Don't do it because there can be member variables that shouldn't be set to zero (hint: std::vector).
        _drawListSharedData = {};
        _drawListSharedData.SetCircleTessellationMaxError(0.3f); // Default value by ImGui v1.84

        _internalFonts._engine = this;
        _internalFonts._isFontAtlasBuilt = false;
        _internalFonts._fontAtlasTexture = nullptr;
    }

    {
        initFonts();
        _fonts.push_back(new Font(this, FontType_Default, 1.25f)); // ImGui Font
        _fonts.push_back(new Font(this, FontType_Default, 1.25f)); // Default Font
        updateFontsIfNeeded();
    }
}

myengine::Engine::~Engine()
{
    VkDevice device = _vk._vulkanDevice->logicalDevice;

    SAFE_DELETE(_copyCmd);
    SAFE_DELETE(_vk._staging_texture);
    SAFE_DELETE(_internalFonts._fontAtlasTexture);

    for (int i = 0; i < _fonts.size(); i++) {
        SAFE_DELETE(_fonts[i]);
    }

    SAFE_DELETE(_iconsTexture);

    // Last destruction because the destruction above needs that device
    {
        VK_SAFE_DESTROY(CommandPool, _vk._vulkanDevice->commandPool);
        _vk._vulkanDevice->logicalDevice = nullptr; // Don't destroy it here.
        SAFE_DELETE(_vk._vulkanDevice);
    }
}


//****************************************************************************************************
// Engine::InternalFonts
//****************************************************************************************************

ImFont *myengine::Engine::InternalFonts::loadFont(const std::string &name, float size)
{
    for (auto it : _fonts) {
        if (_stricmp(it.name.c_str(), name.c_str()) == 0 && it.size == size) {
            return it.font;
        }
    }
    ImGuiIO& io = ImGui::GetIO();
    std::string path = binPath(_engine->_projectName) + "../data/" + name + ".ttf";
    ImFont *font = io.Fonts->AddFontFromFileTTF(path.c_str(), size);
    _fonts.push_back({ to_lower_copy(name), size, font });
    _isFontAtlasBuilt = false;
    return font;
}

void myengine::Engine::InternalFonts::clearFonts()
{
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->Clear();
    _fonts.clear();
    _isFontAtlasBuilt = false;
}

void myengine::Engine::InternalFonts::buildFontAtlas()
{
    vks::VulkanDevice *vulkanDevice = _engine->_vk._vulkanDevice;

    if (!_isFontAtlasBuilt) {
        _isFontAtlasBuilt = true;

        ImGuiIO& io = ImGui::GetIO();

        // Create font texture
        unsigned char *fontData;
        ivec3 extent = { 1, 1, 1 };
        io.Fonts->GetTexDataAsRGBA32(&fontData, &extent.x, &extent.y);
        VkDeviceSize uploadSize = VkDeviceSize(extent.x) * VkDeviceSize(extent.y) * 4 * sizeof(char);

        _engine->_copyCmd->begin();
            if (!_fontAtlasTexture) {
                myengine::TextureCreateInfo CI = {};
                CI.type = myengine::TextureCreateInfoType_Blank;
                CI.extent = { extent.x, extent.y, 1 };
                _fontAtlasTexture = new Texture(_engine, _engine->_copyCmd, CI);
            }
            else {
                _fontAtlasTexture->resize(extent);
            }

            myengine::TextureMappedResource mappedResource = _fontAtlasTexture->map();
            memcpy(mappedResource._rgba_data, fontData, uploadSize);
            _fontAtlasTexture->unmap();
        _engine->_copyCmd->end();

        ImGui_ImplVulkan_UpdateFontsTexture(_fontAtlasTexture->_vk._imageView);

        {
            // Referenced from "imgui.cpp" > SetCurrentFont

            ImFont *font = getFirstFont();
            float fontSize = 0.0f; // TODO: Fix this.

            ImFontAtlas* atlas = font->ContainerAtlas;
            _engine->_drawListSharedData.TexUvWhitePixel = atlas->TexUvWhitePixel; // atlas->TexUvWhitePixel can be changed at any time.
            _engine->_drawListSharedData.TexUvLines = atlas->TexUvLines;
            _engine->_drawListSharedData.Font = font;
            _engine->_drawListSharedData.FontSize = fontSize;
        }
    }
}


//****************************************************************************************************
// Font
//****************************************************************************************************

void myengine::Engine::initFonts()
{
    __resolutionScale = NAN;
    _iDefaultFontSize = 12; // DejaVuSans with size 12 which is the default font of Blender is smaller than Roboto with size 14, and the dot on 'i' of DejaVuSans is more visible than the dot on 'i' of Roboto.
    _areFontsUpdated = false;
}

bool myengine::Engine::setResolutionScale(float scale)
{
    float oldScale = __resolutionScale;
    __resolutionScale = scale;
    if (oldScale != scale) {
        _areFontsUpdated = false; // Linked with Font
        return true;
    }
    return false;
};

void myengine::Engine::updateFontsIfNeeded()
{
    if (_areFontsUpdated) {
        return;
    }
    _areFontsUpdated = true;

    _internalFonts.clearFonts();
    for (auto it : _fonts) {
        if (it->__iSizePixels >= 1) {
            switch (it->getType()) {
            case FontType_Default: it->__font = _internalFonts.loadFont("DejaVuSans", (float)it->__iSizePixels); break;
            case FontType_Script:  it->__font = _internalFonts.loadFont("consola", (float)it->__iSizePixels); break;
            default: assert(0);
            }
        }
        else {
            it->__font = nullptr;
        }
    }
    _internalFonts.buildFontAtlas(); // Not just skipped if there is no change in the FontAtlas because clearFonts forces to rebuild the FontAtlas, but don't worry, the update function is rarely performed.
}

myengine::Font::Font(Engine *engine, FontType type, float scale)
{
    // FIX: Not important to fix but there will be an update if this create function is called even if there shouldn't be an update, like existing type and size.
    _engine = engine;
    //_engine->_areFontsUpdated = false; [error] Not logic because what if that doesn't need to be updated?

    __font = nullptr;
    __type = type;
    __iSizePixels = 0; setScale(scale);
}
myengine::Font::~Font()
{
    // FIX: Not important to fix, same idea as the FIX above.
    _engine->_areFontsUpdated = false;
}

ImFont *myengine::Font::getImFont()
{
    assert(_engine->_areFontsUpdated);
    return __font; // Returns nullptr if the font size is zero.
}

void myengine::Font::setScale(float scale)
{
    int old_iSizePixels = __iSizePixels;
    __iSizePixels = int(scale * _engine->_iDefaultFontSize);
    assert(__iSizePixels >= 0);
    if (old_iSizePixels != __iSizePixels) {
        _engine->_areFontsUpdated = false;
    }
}