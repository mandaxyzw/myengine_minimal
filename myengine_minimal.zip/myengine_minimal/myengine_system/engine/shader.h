#pragma once

#include "common.h"

#include "engine.h"
#include "texture.h"

//****************************************************************************************************
// Shader (FIX: This causes VK_ERROR_DEVICE_LOST when zooming on Blender, today is 12/3/2021)
//****************************************************************************************************
namespace myengine
{
    struct UI_Vertex {
        vec2 pos;
        vec2 uv;
        uint32_t color;
    };

    struct UI_PushConstants {
        vec2 scale;
        vec2 translate;
    };

	class UniformBuffer
	{
	private:
		Engine *_engine;
	public:
		vks::Buffer _vk_buffer;

	public:
		UniformBuffer(Engine *engine, size_t size);
		~UniformBuffer();
		void update(void *data);
	};

    class Shader
    {
    public:
        Engine *_engine;
    private:
        VkRenderPass _renderPass;
		UniformBuffer *_uniformBufferVS; // Don't destroy, because it's from outside.

		//----------

	public:
		// To be destroyed
        VkDescriptorPool _descriptorPool;
        VkDescriptorSetLayout _descriptorSetLayout;
        VkPipelineCache _pipelineCache;
        VkPipelineLayout _pipelineLayout;
        VkDescriptorSet _descriptorSet;
        VkPipeline _pipeline;
        VkPipeline _pipeline_sampleShading;

    public:
        Shader(
            Engine *engine,
            VkRenderPass renderPass,
            UniformBuffer *uniformBufferVS,
            bool vertexShaderEnable,
            Texture *texture);
        ~Shader();
        void bind(VkCommandBuffer commandBuffer);
        void pushConstants(
            VkCommandBuffer     commandBuffer,
            //VkPipelineLayout    layout,
            VkShaderStageFlags  stageFlags,
            uint32_t            offset,
            uint32_t            size,
            const void*         pValues);

    private:
        VkPipelineShaderStageCreateInfo loadShader(std::vector<VkShaderModule> *tmp_shaderModules, std::string fileName, VkShaderStageFlagBits stage);
    };

    class BatchForShader
    {
        // batch_for_shader is a function from Blender Python (GPU Shader Module).
        //
        // Since batches can be drawn multiple times, they should be cached and reused whenever possible. https://docs.blender.org/api/current/gpu.html

	public:
        struct Buffer
        {
            VkBuffer buffer;
            VkDeviceMemory memory;

            Buffer();
            void safe_destroy(Engine *engine);
        };

        Engine *_engine;

        uint32_t _vertexCount;
        Buffer _vertexBuffer;
        size_t _indexItemSizeInBytes;
        uint32_t _indexCount;
        Buffer _indexBuffer;

	public:
		BatchForShader(Engine *engine);
		~BatchForShader();
        void update(size_t vertexItemSizeInBytes, uint32_t vertexCount, void *vertexBufferCPU, size_t indexItemSizeInBytes, uint32_t indexCount, void *indexBufferCPU, VkQueue copyQueue);
        void draw(VkCommandBuffer commandBuffer);
    };
}