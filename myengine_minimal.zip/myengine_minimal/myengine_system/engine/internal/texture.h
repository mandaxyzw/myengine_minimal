#pragma once

#include "common.h"

#include "engine.h"


//****************************************************************************************************
// Texture
//****************************************************************************************************
namespace myengine
{
    enum TextureCreateInfoType
    {
        TextureCreateInfoType_None,
        TextureCreateInfoType_FromFile,
        TextureCreateInfoType_Blank,
        TextureCreateInfoType_UVGrid,
    };

    struct TextureCreateInfo
    {
        TextureCreateInfoType type;
        std::string           fileName;
		ivec3                 extent;
        uint32_t              color;
    };

    struct TextureMappedResource;

    class Texture
    {
	private:
		CopyCommandBuffer *_copyCmd;

    public:
        Texture(Engine *engine, CopyCommandBuffer *copyCmd, TextureCreateInfo &createInfo);
        ~Texture();
        TextureMappedResource map();
        void unmap();
		void resize(const ivec3 &newExtent);

    public:
        struct Vulkan
        {
            // Referenced from "C:\VulkanSDK\1.2.182.0\Demos\cube.cpp" > texture_object
        public:
            Engine *_engine; // Don't destroy, because it's from outside.

			//----------

            ivec3                _extent;
            VkMemoryAllocateInfo _mem_alloc;

            VkSampler            _sampler;
            VkDeviceMemory       _memory;
            VkImage              _image;
            VkImageLayout        _imageLayout;
            VkImageView          _imageView;
            VkBuffer             _buffer;

        public:
			bool _isMapped; // Lesson: It's better to not place this outside the struct Vulkan because resizing the texture needs to recall init that's using of it.
            VkMemoryPropertyFlags _prepare_texture_image__required_props;

        public:
            void init(Engine *engine)
            {
                _engine = engine;
                //--------------------

                _extent = { 0, 0, 0 };
                {
                    _mem_alloc.sType = VkStructureType::VK_STRUCTURE_TYPE_APPLICATION_INFO;
                    _mem_alloc.pNext = nullptr;
                    _mem_alloc.allocationSize = 0;
                    _mem_alloc.memoryTypeIndex = 0;
                }

                _sampler = nullptr;
                _memory = nullptr;
                _image = nullptr;
                _imageLayout = VkImageLayout::VK_IMAGE_LAYOUT_UNDEFINED;
                _imageView = nullptr;
                _buffer = nullptr;

                //--------------------
				_isMapped = false;
                _prepare_texture_image__required_props = 0;
            }

            void destroy()
            {
                VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;

                VK_SAFE_DESTROY(Sampler, _sampler);

                {
                    // clean up staging resources
                    vkFreeMemory(device, _memory, nullptr);
                    VK_SAFE_DESTROY(Image, _image);
                    VK_SAFE_DESTROY(Buffer, _buffer);
                }

                //----------------------------------------------------------------------------------------------------
                VK_SAFE_DESTROY(ImageView, _imageView);
            }

        public:
            TextureMappedResource map();
            void unmap();
            void prepare_texture_image(TextureCreateInfo &createInfo, VkImageTiling tiling, VkImageUsageFlags usage, VkMemoryPropertyFlags required_props);
            void prepare_texture_buffer(TextureCreateInfo &createInfo);
            void prepare_texture(VkCommandBuffer commandBuffer, Texture *staging_texture, TextureCreateInfo &createInfo);
        } _vk;
    };

    struct TextureMappedResource
    {
    public:
        uint8_t             *_rgba_data;
        VkSubresourceLayout  _layout;
        ivec3                _extent;

    public:
        void     setTexel(const ivec2 &pt, uint32_t color);
        uint32_t getTexel(const ivec2 &pt);
        void     drawRect(const ivec2 &a, const ivec2 &b, uint32_t color);
    };
}