#include "texture.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


//****************************************************************************************************
// Texture
//****************************************************************************************************

myengine::Texture::Texture(Engine *engine, CopyCommandBuffer *copyCmd, TextureCreateInfo &createInfo) {
	_copyCmd = copyCmd;
    _vk.init(engine);
    if (createInfo.type != TextureCreateInfoType_None) {
		assert(_copyCmd->_isBegan);
        if (createInfo.fileName == "") {
            assert(createInfo.extent.x > 0 && createInfo.extent.y > 0);
            assert(createInfo.extent.z == 1);
        }
        _vk.prepare_texture(_copyCmd->_vk_copyCmd, engine->_vk._staging_texture, createInfo);
    }
}
myengine::Texture::~Texture() {
	//assert(!_copyCmd->_isBegan); // _copyCmd can be deleted before this.
	assert(!_vk._isMapped); // SORRY, a crash because it's a minimal version with missing codes for speed reason.
    _vk.destroy();
}

myengine::TextureMappedResource myengine::Texture::map() {
	assert(_copyCmd->_isBegan);
	assert(!_vk._isMapped);
	_vk._isMapped = true;
    
	return _vk.map();
}
void myengine::Texture::unmap() {
	assert(_copyCmd->_isBegan);
	assert(_vk._isMapped);
	_vk._isMapped = false;
    
	_vk.unmap();
}

void myengine::Texture::resize(const ivec3 &newExtent)
{
	assert(_copyCmd->_isBegan);
	assert(!_vk._isMapped);
    assert(newExtent.x > 0 && newExtent.y > 0);
    assert(newExtent.z == 1);

	if (_vk._extent.x != newExtent.x ||
		_vk._extent.y != newExtent.y ||
		_vk._extent.z != newExtent.z)
	{
		_vk.destroy();
		_vk.init(_vk._engine);

		TextureCreateInfo CI = {};
		CI.type = TextureCreateInfoType::TextureCreateInfoType_Blank;
		CI.extent = newExtent;
		CI.color = 0xffffffff;
		_vk.prepare_texture(_copyCmd->_vk_copyCmd, _vk._engine->_vk._staging_texture, CI);
	}
}

bool loadTextureFromFile_SLOW(std::string filename, uint8_t *rgba_data, VkSubresourceLayout *layout, int32_t *out_width, int32_t *out_height)
{
    // TODO: Slow because there will be double calling of 'stbi_load'.

    // Load from file
    int image_width = 0;
    int image_height = 0;
    unsigned char* image_data = stbi_load(filename.c_str(), &image_width, &image_height, NULL, 4);
    if (image_data == NULL)
        return false;

    *out_width = image_width;
    *out_height = image_height;

    if (rgba_data == nullptr) {
        return true; // Create the texture outside this function.
    }

    // Fill the created texture
    char *cPtr;
    cPtr = (char *)image_data;
    for (int y = 0; y < image_height; y++) {
        uint8_t *rowPtr = rgba_data;
        for (int x = 0; x < image_width; x++) {
            memcpy(rowPtr, cPtr, 3);
            rowPtr[3] = 255; // Alpha of 1
            rowPtr += 4;
            cPtr += 4;
        }
        rgba_data += layout->rowPitch;
    }
    return true;
}

bool memory_type_from_properties(VkPhysicalDevice physicalDevice, uint32_t typeBits, VkMemoryPropertyFlags requirements_mask, uint32_t *typeIndex)
{
    // Referenced from "C:\VulkanSDK\1.2.182.0\Demos\cube.cpp" > memory_type_from_properties
    // [Double compared: Yes]

    //====================================================================================================
    // Referenced from "C:\VulkanSDK\1.2.182.0\Demos\cube.cpp" > Vulkan::init_vk, Vulkan::init_vk_swapchain
    VkPhysicalDeviceMemoryProperties memory_properties;
    VkPhysicalDevice gpu = physicalDevice;
    vkGetPhysicalDeviceMemoryProperties(gpu, &memory_properties);
    //====================================================================================================

    // Search memtypes to find first index with those properties
    for (uint32_t i = 0; i < VK_MAX_MEMORY_TYPES; i++) {
        if ((typeBits & 1) == 1) {
            // Type is available, does it match user properties?
            if ((memory_properties.memoryTypes[i].propertyFlags & requirements_mask) == requirements_mask) {
                *typeIndex = i;
                return true;
            }
        }
        typeBits >>= 1;
    }

    // No memory types matched, return failure
    return false;
}

myengine::TextureMappedResource myengine::Texture::Vulkan::map()
{
    TextureMappedResource mappedResource = {};
    VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;

    if (_prepare_texture_image__required_props & VkMemoryPropertyFlagBits::VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) {
        VkImageSubresource subres = {};
        subres.aspectMask = VkImageAspectFlagBits::VK_IMAGE_ASPECT_COLOR_BIT;
        subres.mipLevel = 0;
        subres.arrayLayer = 0;
        VkSubresourceLayout layout;
        vkGetImageSubresourceLayout(device, this->_image, &subres, &layout);

        void *data_value;
        VkMemoryMapFlags flags = 0; // It should be zero according to https://www.reddit.com/r/vulkan/comments/4aj5dh/question_vkmapmemory_behaviour/
        VkResult data_result = vkMapMemory(device, this->_memory, 0, this->_mem_alloc.allocationSize, flags, (void **)&data_value);
        VERIFY(data_result == VkResult::VK_SUCCESS);

        mappedResource._rgba_data = (uint8_t *)data_value;
        mappedResource._layout = layout;
        mappedResource._extent = _extent;
    }

    return mappedResource;
}
void myengine::Texture::Vulkan::unmap()
{
    VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;
    vkUnmapMemory(device, this->_memory);
}

void myengine::Texture::Vulkan::prepare_texture_image(TextureCreateInfo &createInfo, VkImageTiling tiling, VkImageUsageFlags usage, VkMemoryPropertyFlags required_props)
{
	// Referenced from "C:\VulkanSDK\1.2.182.0\Demos\cube.cpp" > prepare_texture_image
    // [Double compared: Yes]

	VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;
    VkPhysicalDevice physicalDevice = _engine->_vk._vulkanDevice->physicalDevice;

    ivec3 extent = { 1, 1, 1 };
    uint8_t *image_data = nullptr;
    if (createInfo.type == TextureCreateInfoType_FromFile) {
        image_data = stbi_load(createInfo.fileName.c_str(), &extent.x, &extent.y, nullptr, 4);
        if (image_data == nullptr) {
            myengine_error_exit("Failed to load texture.");
        }
    }
    else if (
        createInfo.type == TextureCreateInfoType_Blank ||
        createInfo.type == TextureCreateInfoType_UVGrid)
    {
        extent = createInfo.extent;
    }

	this->_extent = extent;

	VkImageCreateInfo image_create_info = {};
	image_create_info.imageType = VkImageType::VK_IMAGE_TYPE_2D;
	image_create_info.format = VkFormat::VK_FORMAT_R8G8B8A8_UNORM;
	image_create_info.extent = { (uint32_t)extent.x, (uint32_t)extent.y, (uint32_t)extent.z };
	image_create_info.mipLevels = 1;
	image_create_info.arrayLayers = 1;
	image_create_info.samples = VkSampleCountFlagBits::VK_SAMPLE_COUNT_1_BIT;
	image_create_info.tiling = tiling;
	image_create_info.usage = usage;
	image_create_info.sharingMode = VkSharingMode::VK_SHARING_MODE_EXCLUSIVE;
	image_create_info.queueFamilyIndexCount = 0;
	image_create_info.pQueueFamilyIndices = nullptr;
	image_create_info.initialLayout = VkImageLayout::VK_IMAGE_LAYOUT_PREINITIALIZED;

	auto result = vkCreateImage(device, &image_create_info, nullptr, &this->_image);
	VERIFY(result == VkResult::VK_SUCCESS);

	VkMemoryRequirements mem_reqs;
	vkGetImageMemoryRequirements(device, this->_image, &mem_reqs);

	this->_mem_alloc.allocationSize = mem_reqs.size;
	this->_mem_alloc.memoryTypeIndex = 0;

	auto pass = memory_type_from_properties(physicalDevice, mem_reqs.memoryTypeBits, required_props, &this->_mem_alloc.memoryTypeIndex);
	VERIFY(pass == true);

	result = vkAllocateMemory(device, &this->_mem_alloc, nullptr, &(this->_memory));
	VERIFY(result == VkResult::VK_SUCCESS);

	result = vkBindImageMemory(device, this->_image, this->_memory, 0);
	VERIFY(result == VkResult::VK_SUCCESS);

    // map / unmap
    {
        _prepare_texture_image__required_props = required_props;
        TextureMappedResource mappedResource = map();

        if (createInfo.type == TextureCreateInfoType_FromFile) {
            uint8_t *dst = mappedResource._rgba_data;
            uint8_t *src = image_data;
            for (int y = 0; y < extent.y; y++) {
                uint8_t *rowPtr = dst;
                for (int x = 0; x < extent.x; x++) {
                    memcpy(rowPtr, src, 4);
                    rowPtr += 4;
                    src += 4;
                }
                dst += mappedResource._layout.rowPitch;
            }
            SAFE_FREE(image_data);
        }
        else if (createInfo.type == TextureCreateInfoType_Blank) {
            mappedResource.drawRect(ivec2(0, 0), ivec2(extent.x, extent.y), createInfo.color);
        }
        else if (createInfo.type == TextureCreateInfoType_UVGrid) {
            std::vector<uint32_t> colors = {
                0xff1616e5,
                0xff16b1e5,
                0xff16e57e,
                0xff4ae516,
                0xffe5e516,
                0xffe54a16,
                0xffe5167e,
                0xffb116e5,
            };
            int sqSize = 32;
            for (int y = 0; y < extent.y; y += sqSize) {
                for (int x = 0; x < extent.x; x += sqSize) {
                    int i = x / sqSize;
                    int j = y / sqSize;
                    uint32_t sqColor = ((i - j) % 2 == 0) ? 0xff969696 : 0xff404040;
                    mappedResource.drawRect(ivec2(x, y), ivec2(x + 32, y + 32), sqColor);
                    uint32_t plusColor = colors[abs(i - j) % colors.size()];
                    ivec2 pt = ivec2(x + sqSize / 2, y + sqSize / 2);
                    mappedResource.drawRect(pt + ivec2(-3, 0), pt + ivec2(3, 0) + ivec2(1, 1), plusColor);
                    mappedResource.drawRect(pt + ivec2(0, -3), pt + ivec2(0, 3) + ivec2(1, 1), plusColor);
                }
            }
        }

        unmap();
    }

	this->_imageLayout = VkImageLayout::VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL;
}

void myengine::Texture::Vulkan::prepare_texture_buffer(TextureCreateInfo &createInfo)
{
    // Referenced from "C:\VulkanSDK\1.2.182.0\Demos\cube.cpp" > prepare_texture_buffer
    // [Double compared: Yes]

	VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;
    VkPhysicalDevice physicalDevice = _engine->_vk._vulkanDevice->physicalDevice;

    ivec3 extent = { 1, 1, 1 };
	if (!loadTextureFromFile_SLOW(createInfo.fileName, nullptr, nullptr, &extent.x, &extent.y)) {
        myengine_error_exit("Failed to load texture.");
    }

    this->_extent = extent;

    VkBufferCreateInfo buffer_create_info = {};
    buffer_create_info.size = VkDeviceSize(extent.x) * VkDeviceSize(extent.y) * 4;
    buffer_create_info.usage = VkBufferUsageFlagBits::VK_BUFFER_USAGE_TRANSFER_SRC_BIT;
    buffer_create_info.sharingMode = VkSharingMode::VK_SHARING_MODE_EXCLUSIVE;
    buffer_create_info.queueFamilyIndexCount = 0;
    buffer_create_info.pQueueFamilyIndices = nullptr;

    auto result = vkCreateBuffer(device, &buffer_create_info, nullptr, &this->_buffer);
    VERIFY(result == VkResult::VK_SUCCESS);

    VkMemoryRequirements mem_reqs;
    vkGetBufferMemoryRequirements(device, this->_buffer, &mem_reqs);

    this->_mem_alloc.allocationSize = mem_reqs.size;
    this->_mem_alloc.memoryTypeIndex = 0;

    VkMemoryPropertyFlags requirements = VkMemoryPropertyFlagBits::VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VkMemoryPropertyFlagBits::VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
    auto pass = memory_type_from_properties(physicalDevice, mem_reqs.memoryTypeBits, requirements, &this->_mem_alloc.memoryTypeIndex);
    VERIFY(pass == true);

    result = vkAllocateMemory(device, &this->_mem_alloc, nullptr, &(this->_memory));
    VERIFY(result == VkResult::VK_SUCCESS);

    result = vkBindBufferMemory(device, this->_buffer, this->_memory, 0);
    VERIFY(result == VkResult::VK_SUCCESS);

    VkSubresourceLayout layout;
    layout.rowPitch = extent.x * 4;
	void *data_value;
	VkMemoryMapFlags flags = 0; // It should be zero according to https://www.reddit.com/r/vulkan/comments/4aj5dh/question_vkmapmemory_behaviour/
    VkResult data_result = vkMapMemory(device, this->_memory, 0, this->_mem_alloc.allocationSize, flags, (void **)&data_value);
    VERIFY(data_result == VkResult::VK_SUCCESS);

    if (!loadTextureFromFile_SLOW(createInfo.fileName, (uint8_t *)data_value, &layout, &extent.x, &extent.y)) {
        fprintf(stderr, "Error loading texture: %s\n", createInfo.fileName.c_str());
    }

	vkUnmapMemory(device, this->_memory);
}

void set_image_layout(VkCommandBuffer commandBuffer, VkImage image, VkImageAspectFlags aspectMask, VkImageLayout oldLayout, VkImageLayout newLayout,
	VkAccessFlags srcAccessMask, VkPipelineStageFlags src_stages, VkPipelineStageFlags dest_stages)
{
	// Referenced from "C:\VulkanSDK\1.2.182.0\Demos\cube.cpp" > set_image_layout
    // [Double compared: Yes]

	assert(commandBuffer);

	auto DstAccessMask = [](VkImageLayout const &layout) {
		VkAccessFlags flags;

		switch (layout) {
		case VkImageLayout::VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL:
			// Make sure anything that was copying from this image has
			// completed
			flags = VkAccessFlagBits::VK_ACCESS_TRANSFER_WRITE_BIT;
			break;
		case VkImageLayout::VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL:
			flags = VkAccessFlagBits::VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT;
			break;
		case VkImageLayout::VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL:
			flags = VkAccessFlagBits::VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT;
			break;
		case VkImageLayout::VK_IMAGE_LAYOUT_SHADER_READ_ONLY_OPTIMAL:
			// Make sure any Copy or CPU writes to image are flushed
			flags = VkAccessFlagBits::VK_ACCESS_SHADER_READ_BIT | VkAccessFlagBits::VK_ACCESS_INPUT_ATTACHMENT_READ_BIT;
			break;
		case VkImageLayout::VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL:
			flags = VkAccessFlagBits::VK_ACCESS_TRANSFER_READ_BIT;
			break;
		case VkImageLayout::VK_IMAGE_LAYOUT_PRESENT_SRC_KHR:
			flags = VkAccessFlagBits::VK_ACCESS_MEMORY_READ_BIT;
			break;
		default:
			break;
		}

		return flags;
	};

	VkImageMemoryBarrier barrier = {};
	barrier.srcAccessMask = srcAccessMask;
	barrier.dstAccessMask = DstAccessMask(newLayout);
	barrier.oldLayout = oldLayout;
	barrier.newLayout = newLayout;
	barrier.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
	barrier.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
	barrier.image = image;
	barrier.subresourceRange = { aspectMask, 0, 1, 0, 1 };

	vkCmdPipelineBarrier(commandBuffer, src_stages, dest_stages, VkDependencyFlagBits(), 0, nullptr, 0, nullptr, 1, &barrier);
}

void myengine::Texture::Vulkan::prepare_texture(VkCommandBuffer commandBuffer, Texture *staging_texture, TextureCreateInfo &createInfo)
{
	// Referenced from "C:\VulkanSDK\1.2.182.0\Demos\cube.cpp" > prepare_textures
    // [Double compared: Yes]

	VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;
	VkPhysicalDevice physicalDevice = _engine->_vk._vulkanDevice->physicalDevice;

	VkFormat const tex_format = VkFormat::VK_FORMAT_R8G8B8A8_UNORM;
	VkFormatProperties props;
	vkGetPhysicalDeviceFormatProperties(physicalDevice, tex_format, &props);

	{
		if ((props.linearTilingFeatures & VkFormatFeatureFlagBits::VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT) && !_engine->_vk._useStagingBuffer) {
			// Device can texture using linear textures
			this->prepare_texture_image(createInfo, VkImageTiling::VK_IMAGE_TILING_LINEAR, VkImageUsageFlagBits::VK_IMAGE_USAGE_SAMPLED_BIT,
				VkMemoryPropertyFlagBits::VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VkMemoryPropertyFlagBits::VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
			// Nothing in the pipeline needs to be complete to start, and don't allow fragment
			// shader to run until layout transition completes
			set_image_layout(
                commandBuffer,
                this->_image,
                VkImageAspectFlagBits::VK_IMAGE_ASPECT_COLOR_BIT,
                VkImageLayout::VK_IMAGE_LAYOUT_PREINITIALIZED,
				this->_imageLayout,
                VkAccessFlagBits(),
                VkPipelineStageFlagBits::VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
				VkPipelineStageFlagBits::VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
			staging_texture->_vk._image = VkImage();
		}
		else if (props.optimalTilingFeatures & VkFormatFeatureFlagBits::VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT) {
			// Must use staging buffer to copy linear texture to optimized

            myengine_error("TODO: Staging buffer is not yet fixed.");

			staging_texture->_vk.prepare_texture_buffer(createInfo);

			this->prepare_texture_image(createInfo, VkImageTiling::VK_IMAGE_TILING_OPTIMAL, VkImageUsageFlagBits::VK_IMAGE_USAGE_TRANSFER_DST_BIT | VkImageUsageFlagBits::VK_IMAGE_USAGE_SAMPLED_BIT,
				VkMemoryPropertyFlagBits::VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

			set_image_layout(
                commandBuffer,
                this->_image,
                VkImageAspectFlagBits::VK_IMAGE_ASPECT_COLOR_BIT,
                VkImageLayout::VK_IMAGE_LAYOUT_PREINITIALIZED,
				VkImageLayout::VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                VkAccessFlagBits(),
                VkPipelineStageFlagBits::VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
				VkPipelineStageFlagBits::VK_PIPELINE_STAGE_TRANSFER_BIT);

			VkImageSubresourceLayers subresource = {};
			subresource.aspectMask = VkImageAspectFlagBits::VK_IMAGE_ASPECT_COLOR_BIT;
			subresource.mipLevel = 0;
			subresource.baseArrayLayer = 0;
			subresource.layerCount = 1;

			VkBufferImageCopy copy_region = {};
			copy_region.bufferOffset = 0;
			copy_region.bufferRowLength = staging_texture->_vk._extent.x;
			copy_region.bufferImageHeight = staging_texture->_vk._extent.y;
			copy_region.imageSubresource = subresource;
			copy_region.imageOffset = { 0, 0, 0 };
			copy_region.imageExtent = {
                (uint32_t)staging_texture->_vk._extent.x,
                (uint32_t)staging_texture->_vk._extent.y,
                (uint32_t)staging_texture->_vk._extent.z };

			vkCmdCopyBufferToImage(commandBuffer, staging_texture->_vk._buffer, this->_image, VkImageLayout::VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &copy_region);

			set_image_layout(
                commandBuffer,
                this->_image,
                VkImageAspectFlagBits::VK_IMAGE_ASPECT_COLOR_BIT,
                VkImageLayout::VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
				this->_imageLayout,
                VkAccessFlagBits::VK_ACCESS_TRANSFER_WRITE_BIT,
                VkPipelineStageFlagBits::VK_PIPELINE_STAGE_TRANSFER_BIT,
				VkPipelineStageFlagBits::VK_PIPELINE_STAGE_FRAGMENT_SHADER_BIT);
		}
		else {
			assert(!"No support for R8G8B8A8_UNORM as texture image format");
		}

		VkSamplerCreateInfo samplerInfo = {};
		samplerInfo.magFilter = VkFilter::VK_FILTER_NEAREST;
		samplerInfo.minFilter = VkFilter::VK_FILTER_NEAREST;
		samplerInfo.mipmapMode = VkSamplerMipmapMode::VK_SAMPLER_MIPMAP_MODE_NEAREST;
		samplerInfo.addressModeU = VkSamplerAddressMode::VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
		samplerInfo.addressModeV = VkSamplerAddressMode::VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
		samplerInfo.addressModeW = VkSamplerAddressMode::VK_SAMPLER_ADDRESS_MODE_CLAMP_TO_EDGE;
		samplerInfo.mipLodBias = 0.0f;
		samplerInfo.anisotropyEnable = VK_FALSE;
		samplerInfo.maxAnisotropy = 1;
		samplerInfo.compareEnable = VK_FALSE;
		samplerInfo.compareOp = VkCompareOp::VK_COMPARE_OP_NEVER;
		samplerInfo.minLod = 0.0f;
		samplerInfo.maxLod = 0.0f;
		samplerInfo.borderColor = VkBorderColor::VK_BORDER_COLOR_FLOAT_OPAQUE_WHITE;
		samplerInfo.unnormalizedCoordinates = VK_FALSE;

		auto result = vkCreateSampler(device, &samplerInfo, nullptr, &this->_sampler);
		VERIFY(result == VkResult::VK_SUCCESS);

		VkImageViewCreateInfo viewInfo = {};
		viewInfo.image = this->_image;
		viewInfo.viewType = VkImageViewType::VK_IMAGE_VIEW_TYPE_2D;
		viewInfo.format = tex_format;
        viewInfo.subresourceRange.aspectMask = VkImageAspectFlagBits::VK_IMAGE_ASPECT_COLOR_BIT;
        viewInfo.subresourceRange.baseMipLevel = 0;
        viewInfo.subresourceRange.levelCount = 1;
        viewInfo.subresourceRange.baseArrayLayer = 0;
        viewInfo.subresourceRange.layerCount = 1;

		result = vkCreateImageView(device, &viewInfo, nullptr, &this->_imageView);
		VERIFY(result == VkResult::VK_SUCCESS);
	}
}

//****************************************************************************************************

void myengine::TextureMappedResource::setTexel(const ivec2 &pt, uint32_t color) {
    if (pt.x >= 0 && pt.x < _extent.x &&
        pt.y >= 0 && pt.y < _extent.y)
    {
        uint8_t *ptr0 = _rgba_data + _layout.rowPitch * pt.y;
        uint8_t *ptr = ptr0 + 4 * pt.x;
        *(uint32_t *)ptr = color;
    }
}
uint32_t myengine::TextureMappedResource::getTexel(const ivec2 &pt) {
    if (pt.x >= 0 && pt.x < _extent.x &&
        pt.y >= 0 && pt.y < _extent.y)
    {
        uint8_t *ptr0 = _rgba_data + _layout.rowPitch * pt.y;
        uint8_t *ptr = ptr0 + 4 * pt.x;
        return *(uint32_t *)ptr;
    }
    return 0x00000000;
}

void myengine::TextureMappedResource::drawRect(const ivec2 &a, const ivec2 &b, uint32_t color) {
    int ax = a.x;
    int ay = a.y;
    int bx = b.x;
    int by = b.y;
    if (bx < ax) {
        int tmp = ax;
        ax = bx;
        bx = tmp;
    }
    if (by < ay) {
        int tmp = ay;
        ay = by;
        by = tmp;
    }

    int min_x = max(0, ax);
    int max_x = min(bx, _extent.x);
    int min_y = max(0, ay);
    int max_y = min(by, _extent.y);

    int y = min_y;
    uint8_t *ptr0 = _rgba_data + _layout.rowPitch * y;
    for (; y < max_y; y++) {
        int x = min_x;
        uint8_t *ptr = ptr0 + 4 * x;
        for (; x < max_x; x++) {
            *(uint32_t *)ptr = color;
            ptr += 4;
        }
        ptr0 += _layout.rowPitch;
    }
}