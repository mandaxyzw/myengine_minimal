#pragma once

#include "common.h"

//****************************************************************************************************
// CopyCommandBuffer
//****************************************************************************************************
namespace myengine
{
	class Engine;

	class CopyCommandBuffer
	{
        friend class Texture;
    private:
		Engine *_engine;
		bool _isBegan;
		VkCommandBuffer _vk_copyCmd;

    public:
		CopyCommandBuffer(Engine *engine);
		void begin();
		void end();
	};
}


//****************************************************************************************************
// Engine
//****************************************************************************************************
namespace myengine
{
    class Engine
    {
        friend class Engine;
        friend class UniformBuffer;
        friend class Shader;
        friend class BatchForShader;
        friend class Compute;
        friend class CopyCommandBuffer;
        friend class Texture;

        friend class DrawList;
        friend class Font;

    public:
        Engine(const char *projectName, VkPhysicalDevice physicalDevice, VkDevice device, uint32_t queueFamily, VkQueue copyQueue, bool useStagingBuffer);
        ~Engine();

    private:
        std::string _projectName;
		CopyCommandBuffer *_copyCmd;

        struct
        {
            VkPhysicalDeviceFeatures _enabledFeatures;           // ????? is it needed ???????????????? is it needed ???????????????????????????????????
	        std::vector<const char*> _enabledDeviceExtensions;   // ????? is it needed ???????????????? is it needed ???????????????????????????????????
	        std::vector<const char*> _enabledInstanceExtensions; // ????? is it needed ???????????????? is it needed ???????????????????????????????????
            void *_deviceCreatepNextChain;                       // ????? is it needed ???????????????? is it needed ???????????????????????????????????
            vks::VulkanDevice *_vulkanDevice;                    // Don't completely destroy
            VkQueue _copyQueue;                                  // Don't destroy, because it's from outside.
            bool _useStagingBuffer;                              //

            //----------

            Texture *_staging_texture;
        } _vk;

        //----------------------------------------------------------------------------------------------------

    private:
        ImDrawListSharedData _drawListSharedData;

        struct InternalFonts
        {
            Engine *_engine;
            struct FontItem {
                std::string name;
                float size;
                ImFont *font;
            };
            std::vector<FontItem> _fonts;
            bool _isFontAtlasBuilt;
            Texture *_fontAtlasTexture;

            ImFont *loadFont(const std::string &name, float size);
            void clearFonts();
            ImFont *getFirstFont() { assert(_fonts.size() != 0); return _fonts[0].font; } // Index 0 because all fonts atlases are in the same texture.
            void buildFontAtlas();
        } _internalFonts;

        //----------------------------------------------------------------------------------------------------

    private:
        float __resolutionScale; // Internal: Linked with Font.
        int _iDefaultFontSize;
        std::vector<Font *> _fonts;
        bool _areFontsUpdated;

    public:
        void initFonts();
        bool setResolutionScale(float scale); // Returns true if an update is needed, otherwise returns false.
        float getResolutionScale() { assert(!isnan(__resolutionScale) && "The resolution scale is not yet set."); return __resolutionScale; }
        void updateFontsIfNeeded(); // It can be called every frame because there is a checking if it needs to be performed.
        Font *getImGuiFont()   { assert(_fonts.size() >= 1); return _fonts[0]; }
        Font *getDefaultFont() { assert(_fonts.size() >= 2); return _fonts[1]; }

        //----------------------------------------------------------------------------------------------------

    private:
        ivec2 _iconsTexture_size;
        Texture *_iconsTexture;
    };

    enum FontType {
        FontType_Default,
        FontType_Script,
    };

    class Font {
        friend class Engine;
    private:
        Engine *_engine;

    private: // Always private because internal
        ImFont *__font;    // Private because not safe, it can be nullptr, and the fonts must be updated.
        FontType __type;   // Internal:
        int __iSizePixels; // Internal: Size in pixels, check ImFontAtlas::AddFont for proof. It's 'int' because for example 14.5 causes artifact.

    private: // Private because must only be created privately.
        Font(Engine *engine, FontType type, float scale); // Private
        ~Font(); // Private
    public:
        ImFont *getImFont();
        FontType getType() { return __type; }
        void setScale(float scale);
    };
}