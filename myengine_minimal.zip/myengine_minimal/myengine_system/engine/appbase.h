#pragma once

#include "common.h"

#include "engine.h"

namespace myengine
{
    class AppBase_Internal
    {
    public:
        Engine *_engine;
    private:
        friend class AppBase;
        AppBase *_appBase;

        AppBase_Internal(AppBase *appBase) {
            _engine = nullptr;
            _appBase = appBase;
        }
        void FrameRender(ImGui_ImplVulkanH_Window* wd, ImDrawData* draw_data);

        void prepareGui_base(VkRenderPass renderPass);
        void destroyGui_base();
    };

    class AppBase : public AppBase_Internal
    {
    public:
        AppBase() : AppBase_Internal(this) {}
        virtual void imGuiDebug() {}
        virtual void destroyGui() {}
        void buildFontAtlasIfNeeded() {
            _engine->updateFontsIfNeeded();
        }
        virtual void beforeFrameRender() {}
        int main(const char *title, const ivec2 &windowSize, const char *projectName);
    };
}