#include "shader.h"

myengine::UniformBuffer::UniformBuffer(Engine *engine, size_t size)
{
	// Referenced from "examples/imgui/main.cpp" > prepareUniformBuffers in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
	_engine = engine;
    VK_CHECK_RESULT(_engine->_vk._vulkanDevice->createBuffer(
        VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
        &_vk_buffer,
        size,
        nullptr));
}
myengine::UniformBuffer::~UniformBuffer()
{
	_vk_buffer.destroy();
}
void myengine::UniformBuffer::update(void *data)
{
	// Referenced from "examples/imgui/main.cpp" > updateUniformBuffers in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
    VK_CHECK_RESULT(_vk_buffer.map());
    memcpy(_vk_buffer.mapped, data, _vk_buffer.size);
    _vk_buffer.unmap();
}

//****************************************************************************************************

myengine::Shader::Shader(
    Engine *engine,
    VkRenderPass renderPass,
    UniformBuffer *uniformBufferVS,
    bool vertexShaderEnable,
    Texture *texture) :

    _engine{ engine },
    _renderPass{ renderPass },
    _uniformBufferVS{ uniformBufferVS },
	//----------
    _descriptorPool{ nullptr },
    _descriptorSetLayout{ nullptr },
    _pipelineCache{ nullptr },
    _pipelineLayout{ nullptr },
    _descriptorSet{ nullptr },
    _pipeline{ nullptr },
    _pipeline_sampleShading{ nullptr }
{
    VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;

    // Reference:
    // - The (vertexShaderEnable == true ) is from "examples/imgui/main.cpp" > setupLayoutsAndDescriptors / preparePipelines in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
    // - The (vertexShaderEnable == false) is from "examples/imgui/main.cpp" > initResources in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
    // - Difference: vertexShaderEnable, depthEnable

    bool depthEnable = VK_FALSE;

    //------------------------------ Descriptors and Layouts ------------------------------

    // Descriptor pool
    std::vector<VkDescriptorPoolSize> poolSizes;
    {
        // binding++:
        if (vertexShaderEnable) {
            poolSizes.push_back(vks::initializers::descriptorPoolSize(VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 2));
        }
        // binding++:
        poolSizes.push_back(vks::initializers::descriptorPoolSize(VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER, 1));
    }
    VkDescriptorPoolCreateInfo descriptorPoolInfo = vks::initializers::descriptorPoolCreateInfo(poolSizes, 2);
    VK_CHECK_RESULT(vkCreateDescriptorPool(device, &descriptorPoolInfo, nullptr, &_descriptorPool));

    // Descriptor set layout
    {
        // Referenced from "texture.cpp" in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
        std::vector<VkDescriptorSetLayoutBinding> setLayoutBindings;
        uint32_t binding = 0;
        if (vertexShaderEnable) {
            // binding++: Vertex shader uniform buffer
            setLayoutBindings.push_back(
                vks::initializers::descriptorSetLayoutBinding(
                    VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
                    VK_SHADER_STAGE_VERTEX_BIT,
                    binding++));
        }
        // binding++: Fragment shader image sampler
        setLayoutBindings.push_back(
            vks::initializers::descriptorSetLayoutBinding(
                VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,
                VK_SHADER_STAGE_FRAGMENT_BIT,
                binding++));
        VkDescriptorSetLayoutCreateInfo descriptorLayout = vks::initializers::descriptorSetLayoutCreateInfo(setLayoutBindings);
        VK_CHECK_RESULT(vkCreateDescriptorSetLayout(device, &descriptorLayout, nullptr, &_descriptorSetLayout));
    }

    // Descriptor set
    {
        // Referenced from "texture.cpp" in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan

        VkDescriptorSetAllocateInfo allocInfo = vks::initializers::descriptorSetAllocateInfo(_descriptorPool, &_descriptorSetLayout, 1);
        VK_CHECK_RESULT(vkAllocateDescriptorSets(device, &allocInfo, &_descriptorSet));

        std::vector<VkWriteDescriptorSet> writeDescriptorSets;
        uint32_t binding = 0;

        if (vertexShaderEnable) {
            // binding++ : Vertex shader uniform buffer
            writeDescriptorSets.push_back(
                vks::initializers::writeDescriptorSet(
                    _descriptorSet,
                    VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
                    binding++,
                    &_uniformBufferVS->_vk_buffer.descriptor));
        }

        // binding++ : Fragment shader texture sampler
        //   Fragment shader: layout (binding) uniform sampler2D samplerColor;
        if (texture) {
            // Setup a descriptor image info for the current texture to be used as a combined image sampler
            VkDescriptorImageInfo textureDescriptor = vks::initializers::descriptorImageInfo(
                texture->_vk._sampler,     // The sampler (Telling the pipeline how to sample the texture, including repeat, border, etc.)
                texture->_vk._imageView,   // The image's view (images are never directly accessed by the shader, but rather through views defining subresources)
                texture->_vk._imageLayout  // The current layout of the image (Note: Should always fit the actual use, e.g. shader read)
            );

            writeDescriptorSets.push_back(
                vks::initializers::writeDescriptorSet(
                    _descriptorSet,
                    VK_DESCRIPTOR_TYPE_COMBINED_IMAGE_SAMPLER,  // The descriptor set will use a combined image sampler (sampler and image could be split)
                    binding++,                                  // Shader binding
                    &textureDescriptor));                       // Pointer to the descriptor image for our texture
        }

        vkUpdateDescriptorSets(device, static_cast<uint32_t>(writeDescriptorSets.size()), writeDescriptorSets.data(), 0, nullptr);
    }

    //------------------------------ Pipeline ------------------------------

    // Pipeline cache
    {
        VkPipelineCacheCreateInfo pipelineCacheCreateInfo = {};
        pipelineCacheCreateInfo.sType = VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO;
        VK_CHECK_RESULT(vkCreatePipelineCache(device, &pipelineCacheCreateInfo, nullptr, &_pipelineCache));
    }

    // Pipeline layout
    {
        // Push constants for rendering parameters
        uint32_t size;
        switch (0) {
        case 0:
            size = sizeof(UI_PushConstants);
            break;
        default:
            myengine_error("");
        }
        VkPushConstantRange pushConstantRange = vks::initializers::pushConstantRange(VK_SHADER_STAGE_VERTEX_BIT, size, 0);
        VkPipelineLayoutCreateInfo pipelineLayoutCreateInfo = vks::initializers::pipelineLayoutCreateInfo(&_descriptorSetLayout, 1);
        pipelineLayoutCreateInfo.pushConstantRangeCount = 1;
        pipelineLayoutCreateInfo.pPushConstantRanges = &pushConstantRange;
        VK_CHECK_RESULT(vkCreatePipelineLayout(device, &pipelineLayoutCreateInfo, nullptr, &_pipelineLayout));
    }

    // Pipeline
    {
        // Setup graphics pipeline
        VkPipelineInputAssemblyStateCreateInfo inputAssemblyState = vks::initializers::pipelineInputAssemblyStateCreateInfo(VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST, 0, VK_FALSE);
        VkPipelineRasterizationStateCreateInfo rasterizationState = vks::initializers::pipelineRasterizationStateCreateInfo(VK_POLYGON_MODE_FILL, VK_CULL_MODE_NONE, VK_FRONT_FACE_COUNTER_CLOCKWISE);

        // Enable blending
        VkPipelineColorBlendAttachmentState blendAttachmentState{};
        if (false) {
            blendAttachmentState = vks::initializers::pipelineColorBlendAttachmentState(0xf, VK_FALSE);
        }
        else {
            blendAttachmentState.blendEnable = VK_TRUE;
            blendAttachmentState.srcColorBlendFactor = VK_BLEND_FACTOR_SRC_ALPHA;
            blendAttachmentState.dstColorBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
            blendAttachmentState.colorBlendOp = VK_BLEND_OP_ADD;
            blendAttachmentState.srcAlphaBlendFactor = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
            blendAttachmentState.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO;
            blendAttachmentState.alphaBlendOp = VK_BLEND_OP_ADD;
            blendAttachmentState.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT | VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
        }
        VkPipelineColorBlendStateCreateInfo colorBlendState = vks::initializers::pipelineColorBlendStateCreateInfo(1, &blendAttachmentState);

        VkPipelineDepthStencilStateCreateInfo depthStencilState = vks::initializers::pipelineDepthStencilStateCreateInfo(depthEnable, depthEnable, VK_COMPARE_OP_LESS_OR_EQUAL);

        VkPipelineViewportStateCreateInfo viewportState = vks::initializers::pipelineViewportStateCreateInfo(1, 1, 0);
        VkPipelineMultisampleStateCreateInfo multisampleState = vks::initializers::pipelineMultisampleStateCreateInfo(VK_SAMPLE_COUNT_1_BIT);
        std::vector<VkDynamicState> dynamicStateEnables = { VK_DYNAMIC_STATE_VIEWPORT, VK_DYNAMIC_STATE_SCISSOR };
        VkPipelineDynamicStateCreateInfo dynamicState = vks::initializers::pipelineDynamicStateCreateInfo(dynamicStateEnables);

        //----------------------------------------------------------------------------------------------------

        // Vertex bindings and attributes
        std::vector<VkVertexInputAttributeDescription> vertexInputAttributes;
        uint32_t stride = 0;
        switch (0) {
        case 0:
            stride = sizeof(myengine::UI_Vertex);
            vertexInputAttributes = {
                vks::initializers::vertexInputAttributeDescription(0, 0, VK_FORMAT_R32G32_SFLOAT, offsetof(myengine::UI_Vertex, pos)),
                vks::initializers::vertexInputAttributeDescription(0, 1, VK_FORMAT_R32G32_SFLOAT, offsetof(myengine::UI_Vertex, uv)),
                vks::initializers::vertexInputAttributeDescription(0, 2, VK_FORMAT_R8G8B8A8_UNORM, offsetof(myengine::UI_Vertex, color)),
            };
            break;
        default:
            myengine_error("");
        }
        std::vector<VkVertexInputBindingDescription> vertexInputBindings = {
            vks::initializers::vertexInputBindingDescription(0, stride, VK_VERTEX_INPUT_RATE_VERTEX),
        };
        VkPipelineVertexInputStateCreateInfo vertexInputState = vks::initializers::pipelineVertexInputStateCreateInfo();
        vertexInputState.vertexBindingDescriptionCount = static_cast<uint32_t>(vertexInputBindings.size());
        vertexInputState.pVertexBindingDescriptions = vertexInputBindings.data();
        vertexInputState.vertexAttributeDescriptionCount = static_cast<uint32_t>(vertexInputAttributes.size());
        vertexInputState.pVertexAttributeDescriptions = vertexInputAttributes.data();

        //----------------------------------------------------------------------------------------------------

        std::vector<VkShaderModule> tmp_shaderModules;
        std::array<VkPipelineShaderStageCreateInfo, 2> shaderStages{};

        VkGraphicsPipelineCreateInfo pipelineCI = vks::initializers::pipelineCreateInfo(_pipelineLayout, _renderPass);
        pipelineCI.stageCount = static_cast<uint32_t>(shaderStages.size());
        pipelineCI.pStages = shaderStages.data();
        pipelineCI.pVertexInputState = &vertexInputState;
        pipelineCI.pInputAssemblyState = &inputAssemblyState;
        pipelineCI.pViewportState = &viewportState;
        pipelineCI.pRasterizationState = &rasterizationState;
        pipelineCI.pMultisampleState = &multisampleState;
        pipelineCI.pDepthStencilState = &depthStencilState;
        pipelineCI.pColorBlendState = &colorBlendState;
        pipelineCI.pDynamicState = &dynamicState;

        std::string name = "ui";
        std::string path = binPath(_engine->_projectName) + "../data/shaders";
        shaderStages[0] = loadShader(&tmp_shaderModules, path + "/" + name + ".vert.spv", VK_SHADER_STAGE_VERTEX_BIT);
        shaderStages[1] = loadShader(&tmp_shaderModules, path + "/" + name + ".frag.spv", VK_SHADER_STAGE_FRAGMENT_BIT);
        VK_CHECK_RESULT(vkCreateGraphicsPipelines(device, _pipelineCache, 1, &pipelineCI, nullptr, &_pipeline));

        // Cleanup
        for (auto &shaderModule : tmp_shaderModules) {
            vkDestroyShaderModule(device, shaderModule, nullptr);
        }
    }
}

myengine::Shader::~Shader()
{
    VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;
    VK_SAFE_DESTROY(DescriptorPool     , _descriptorPool);
    VK_SAFE_DESTROY(DescriptorSetLayout, _descriptorSetLayout);
    VK_SAFE_DESTROY(PipelineCache      , _pipelineCache);
    VK_SAFE_DESTROY(PipelineLayout     , _pipelineLayout);
    VK_SAFE_DESTROY(Pipeline           , _pipeline);
}

void myengine::Shader::bind(VkCommandBuffer commandBuffer)
{
    vkCmdBindDescriptorSets(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, _pipelineLayout, 0, 1, &_descriptorSet, 0, nullptr);
    vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_GRAPHICS, _pipeline);
}

void myengine::Shader::pushConstants(
    VkCommandBuffer     commandBuffer,
    //VkPipelineLayout    layout,
    VkShaderStageFlags  stageFlags,
    uint32_t            offset,
    uint32_t            size,
    const void*         pValues)
{
    vkCmdPushConstants(
        commandBuffer,
        _pipelineLayout,
        stageFlags,
        offset,
        size,
        pValues);
}

VkPipelineShaderStageCreateInfo myengine::Shader::loadShader(std::vector<VkShaderModule> *tmp_shaderModules, std::string fileName, VkShaderStageFlagBits stage)
{
    // Referenced from "vulkanexamplebase.cpp" in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan
    VkDevice device = _engine->_vk._vulkanDevice->logicalDevice;

    VkPipelineShaderStageCreateInfo shaderStage = {};
    shaderStage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    shaderStage.stage = stage;
#if defined(VK_USE_PLATFORM_ANDROID_KHR)
    shaderStage.module = vks::tools::loadShader(androidApp->activity->assetManager, fileName.c_str(), device);
#else
    shaderStage.module = vks::tools::loadShader(fileName.c_str(), device);
#endif
    shaderStage.pName = "main";
    assert(shaderStage.module != VK_NULL_HANDLE);
    tmp_shaderModules->push_back(shaderStage.module);
    return shaderStage;
}

//****************************************************************************************************

myengine::BatchForShader::BatchForShader(Engine *engine) {
    _engine = engine;

    _vertexCount = 0;
    _vertexBuffer = {};
    _indexItemSizeInBytes = 0;
    _indexCount = 0;
    _indexBuffer = {};
}
myengine::BatchForShader::~BatchForShader() {
    _vertexBuffer.safe_destroy(_engine);
    _indexBuffer.safe_destroy(_engine);
}

myengine::BatchForShader::Buffer::Buffer() {
    buffer = nullptr;
    memory = nullptr;
}

void myengine::BatchForShader::Buffer::safe_destroy(Engine *engine) {
    VkDevice device = engine->_vk._vulkanDevice->logicalDevice;
    if (buffer) {
        vkDestroyBuffer(device, buffer, nullptr);
        buffer = nullptr;
    }
    if (memory) {
        vkFreeMemory(device, memory, nullptr);
        memory = nullptr;
    }
}

void myengine::BatchForShader::update(size_t vertexItemSizeInBytes, uint32_t vertexCount, void *vertexBufferCPU, size_t indexItemSizeInBytes, uint32_t indexCount, void *indexBufferCPU, VkQueue copyQueue)
{
    vks::VulkanDevice *vulkanDevice = _engine->_vk._vulkanDevice;

    this->_vertexCount = vertexCount;
    size_t vertexBufferSize = vertexItemSizeInBytes * vertexCount;
    this->_indexItemSizeInBytes = indexItemSizeInBytes;
    this->_indexCount = indexCount;
    size_t indexBufferSize = indexItemSizeInBytes * indexCount;

    if ((vertexBufferSize == 0) || (indexBufferSize == 0))
    {
        // _vertexCount is set to 0 OR _indexCount is set to 0
        return;
    }

    //if (_engine->_vk._useStagingBuffer)
    if (true)
    {
        // Static data like vertex and index buffer should be stored on the device memory
        // for optimal (and fastest) access by the GPU
        //
        // ... (information from "triangle.cpp" in "Vulkan C++ examples and demos" https://github.com/SaschaWillems/Vulkan)

        myengine::BatchForShader::Buffer vertexStaging, indexStaging;

        //----- Referenced from "VulkanglTFModel.cpp" -----

        // Create staging buffers
        // Vertex data
        VK_CHECK_RESULT(vulkanDevice->createBuffer(
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
            vertexBufferSize,
            &vertexStaging.buffer,
            &vertexStaging.memory,
            vertexBufferCPU));
        // Index data
        VK_CHECK_RESULT(vulkanDevice->createBuffer(
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
            indexBufferSize,
            &indexStaging.buffer,
            &indexStaging.memory,
            indexBufferCPU));

        VkMemoryPropertyFlags memoryPropertyFlags = 0;

        // There will be memory leak without destroying before re-creating.
        _vertexBuffer.safe_destroy(_engine);
        _indexBuffer.safe_destroy(_engine);

        // Create device local buffers
        // Vertex buffer
        VK_CHECK_RESULT(vulkanDevice->createBuffer(
            VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT | memoryPropertyFlags,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
            vertexBufferSize,
            &_vertexBuffer.buffer,
            &_vertexBuffer.memory));
        // Index buffer
        VK_CHECK_RESULT(vulkanDevice->createBuffer(
            VK_BUFFER_USAGE_INDEX_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT | memoryPropertyFlags,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
            indexBufferSize,
            &_indexBuffer.buffer,
            &_indexBuffer.memory));

        // Buffer copies have to be submitted to a queue, so we need a command buffer for them
        // Note: Some devices offer a dedicated transfer queue (with only the transfer bit set) that may be faster when doing lots of copies
        {
            // Copy from staging buffers
            VkCommandBuffer copyCmd = vulkanDevice->createCommandBuffer(VK_COMMAND_BUFFER_LEVEL_PRIMARY, true);

            VkBufferCopy copyRegion = {};

            copyRegion.size = vertexBufferSize;
            vkCmdCopyBuffer(copyCmd, vertexStaging.buffer, _vertexBuffer.buffer, 1, &copyRegion);
            copyRegion.size = indexBufferSize;
            vkCmdCopyBuffer(copyCmd, indexStaging.buffer, _indexBuffer.buffer, 1, &copyRegion);

            vulkanDevice->flushCommandBuffer(copyCmd, copyQueue, true);
        }

        vertexStaging.safe_destroy(_engine);
        indexStaging.safe_destroy(_engine);
    }
    else
    {
        // Not using of staging
        // Create host-visible buffers only and use these for rendering. This is not advised and will usually result in lower rendering performance

        myengine_error("Not using of staging buffer is not advised.");
    }
}

void myengine::BatchForShader::draw(VkCommandBuffer commandBuffer)
{
    if (this->_indexCount == 0) {
        return;
    }

    // Bind buffers
    //if (!buffersBound)
    {
        const VkDeviceSize offsets[1] = { 0 };
        vkCmdBindVertexBuffers(commandBuffer, 0, 1, &_vertexBuffer.buffer, offsets);

        VkIndexType indexType;
        switch (_indexItemSizeInBytes) {
        case 2:
            indexType = VK_INDEX_TYPE_UINT16;
            break;
        case 4:
            indexType = VK_INDEX_TYPE_UINT32;
            break;
        default:
            myengine_error("");
        }
        vkCmdBindIndexBuffer(commandBuffer, _indexBuffer.buffer, 0, indexType);
    }

    // Draw
    vkCmdDrawIndexed(commandBuffer, _indexCount, 1, 0, 0, 0);
}