#include "common.h"

//****************************************************************************************************
// String
//****************************************************************************************************

std::string to_lower_copy(const std::string &str) {
    // Referenced from https://stackoverflow.com/questions/313970/how-to-convert-an-instance-of-stdstring-to-lower-case
    std::string data = str;
    std::transform(data.begin(), data.end(), data.begin(), [](unsigned char c) { return std::tolower(c); });
    return data;
}
std::string to_upper_copy(const std::string &str) {
    // Referenced from https://stackoverflow.com/questions/313970/how-to-convert-an-instance-of-stdstring-to-lower-case
    std::string data = str;
    std::transform(data.begin(), data.end(), data.begin(), [](unsigned char c) { return std::toupper(c); });
    return data;
}

//****************************************************************************************************
// Path
//****************************************************************************************************

// https://stackoverflow.com/questions/20358455/cross-platform-way-to-make-a-directory-including-subfolders
#if __cplusplus < 201703L // If the version of C++ is less than 17
#include <experimental/filesystem>
// It was still in the experimental:: namespace
namespace fs = std::experimental::filesystem;
#else
#include <filesystem>
namespace fs = std::filesystem;
#endif

std::string currentPath()
{
    return fs::current_path().string();
}

std::string pathFolderName(std::string path)
{
    fs::path p = path;
    return p.filename().string();
}

std::string binPath(const std::string &projectName)
{
    std::string p = currentPath();
    std::string folderName = pathFolderName(p);
    if (folderName == projectName) {
        p = p + "/../../bin/";
    }
    else {
        p = p + "/";
    }
    return p;
}