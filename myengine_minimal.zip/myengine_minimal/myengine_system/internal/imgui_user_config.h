// Referenced from "imconfig.h".

#pragma once

//---- Define constructor and implicit cast operators to convert back<>forth between your math types and ImVec2/ImVec4.
// This will be inlined as part of ImVec2 and ImVec4 class declarations.
#define IM_VEC2_CLASS_EXTRA                                                 \
        ImVec2(const myengine::vec2& f) { x = f.x; y = f.y; }                    \
        operator myengine::vec2() const { return myengine::vec2(x,y); }
#define IM_VEC4_CLASS_EXTRA                                                 \
        ImVec4(const myengine::vec4& f) { x = f.x; y = f.y; z = f.z; w = f.w; }  \
        operator myengine::vec4() const { return myengine::vec4(x,y,z,w); }