#pragma once

//****************************************************************************************************
// Vector
//****************************************************************************************************
// The reason I use custom vec3 is because the debug of glm::vec3 is so complex, it's very difficult to
// read, also, the "step into" (F11) with glm::vec3 has so many sub steps, I need a fast debug.

namespace myengine
{
#define MACRO_MINMAX(Tz, Tx, Ty) \
    inline Tz min(Tx x, Ty y) { if (x < y) return x; return y; } \
    inline Tz max(Tx x, Ty y) { if (x > y) return x; return y; }

    MACRO_MINMAX(int   , int   , int   )
  //MACRO_MINMAX(size_t, int   , size_t) // Warning C4018 '<' / '>': signed/unsigned mismatch
  //MACRO_MINMAX(float , int   , float ) // 'return': conversion from 'int' to 'float', possible loss of data
    MACRO_MINMAX(double, int   , double)

  //MACRO_MINMAX(size_t, size_t, int   ) // Warning C4018 '<' / '>': signed/unsigned mismatch
    MACRO_MINMAX(size_t, size_t, size_t)
  //MACRO_MINMAX(float , size_t, float ) // 'return': conversion from 'std::size_t' to 'float', possible loss of data
  //MACRO_MINMAX(double, size_t, double) // 'return': conversion from 'std::size_t' to 'double', possible loss of data

  //MACRO_MINMAX(float , float , int   ) // 'return': conversion from 'int' to 'float', possible loss of data
  //MACRO_MINMAX(float , float , size_t) // 'return': conversion from 'std::size_t' to 'float', possible loss of data
    MACRO_MINMAX(float , float , float )
    MACRO_MINMAX(double, float , double)

    MACRO_MINMAX(double, double, int   )
  //MACRO_MINMAX(double, double, size_t) // 'return': conversion from 'std::size_t' to 'double', possible loss of data
    MACRO_MINMAX(double, double, float )
    MACRO_MINMAX(double, double, double)

	struct vec2 {
		float x, y;
		vec2() = default;
		vec2(float _x, float _y) : x(_x), y(_y) {}
	};
	struct vec3 {
		float x, y, z;
		vec3() = default;
		vec3(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
		vec3(const vec2 &v, float _z) : vec3(v.x, v.y, _z) {}
	};
	struct vec4 {
		float x, y, z, w;
		vec4() = default;
		vec4(float _x, float _y, float _z, float _w) : x(_x), y(_y), z(_z), w(_w) {}
	};
	struct ivec2 {
		int x, y;
		ivec2() = default;
		ivec2(int _x, int _y) : x(_x), y(_y) {}
	};
	struct ivec3 {
		int x, y, z;
		ivec3() = default;
		ivec3(int _x, int _y, int _z) : x(_x), y(_y), z(_z) {}
		ivec3(const ivec2 &v, int _z) : ivec3(v.x, v.y, _z) {}
	};
	struct ivec4 {
		int x, y, z, w;
		ivec4() = default;
		ivec4(int _x, int _y, int _z, int _w) : x(_x), y(_y), z(_z), w(_w) {}
	};

#define MACRO_VEC(VEC1, VEC, v_div_x) \
    inline VEC##2 operator+ (VEC##2  v1, VEC##2  v2) { return VEC##2(v1.x + v2.x, v1.y + v2.y                          ); } \
    inline VEC##3 operator+ (VEC##3  v1, VEC##3  v2) { return VEC##3(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z             ); } \
    inline VEC##4 operator+ (VEC##4  v1, VEC##4  v2) { return VEC##4(v1.x + v2.x, v1.y + v2.y, v1.z + v2.z, v1.w + v2.w); } \
    inline VEC##2 operator- (VEC##2  v1, VEC##2  v2) { return VEC##2(v1.x - v2.x, v1.y - v2.y                          ); } \
    inline VEC##3 operator- (VEC##3  v1, VEC##3  v2) { return VEC##3(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z             ); } \
    inline VEC##4 operator- (VEC##4  v1, VEC##4  v2) { return VEC##4(v1.x - v2.x, v1.y - v2.y, v1.z - v2.z, v1.w - v2.w); } \
    inline VEC##2 operator- (VEC##2  v             ) { return VEC##2(     - v .x,      - v .y                          ); } \
    inline VEC##3 operator- (VEC##3  v             ) { return VEC##3(     - v .x,      - v .y,      - v .z             ); } \
    inline VEC##4 operator- (VEC##4  v             ) { return VEC##4(     - v .x,      - v .y,      - v .z,      - v .w); } \
    inline VEC##2 operator* (VEC1    x , VEC##2  v ) { return VEC##2(   x * v .x,    x * v .y                          ); } \
    inline VEC##3 operator* (VEC1    x , VEC##3  v ) { return VEC##3(   x * v .x,    x * v .y,    x * v .z             ); } \
    inline VEC##4 operator* (VEC1    x , VEC##4  v ) { return VEC##4(   x * v .x,    x * v .y,    x * v .z,    x * v .w); } \
    inline VEC##2 operator* (VEC##2  v , VEC1    x ) { return VEC##2(v .x *    x, v .y *    x                          ); } \
    inline VEC##3 operator* (VEC##3  v , VEC1    x ) { return VEC##3(v .x *    x, v .y *    x, v .z *    x             ); } \
    inline VEC##4 operator* (VEC##4  v , VEC1    x ) { return VEC##4(v .x *    x, v .y *    x, v .z *    x,  v.w *    x); } \
    inline VEC##2 operator/ (VEC##2  v , VEC1    x ) { return (v_div_x); } \
    inline VEC##3 operator/ (VEC##3  v , VEC1    x ) { return (v_div_x); } \
    inline VEC##4 operator/ (VEC##4  v , VEC1    x ) { return (v_div_x); } \
    inline VEC##2 operator+=(VEC##2 &v1, VEC##2  v2) { return v1 = v1 + v2; } \
    inline VEC##3 operator+=(VEC##3 &v1, VEC##3  v2) { return v1 = v1 + v2; } \
    inline VEC##4 operator+=(VEC##4 &v1, VEC##4  v2) { return v1 = v1 + v2; } \
    inline VEC##2 operator-=(VEC##2 &v1, VEC##2  v2) { return v1 = v1 - v2; } \
    inline VEC##3 operator-=(VEC##3 &v1, VEC##3  v2) { return v1 = v1 - v2; } \
    inline VEC##4 operator-=(VEC##4 &v1, VEC##4  v2) { return v1 = v1 - v2; } \
    inline VEC##2 operator*=(VEC##2 &v , VEC1    x ) { return v  = v  * x ; } \
    inline VEC##3 operator*=(VEC##3 &v , VEC1    x ) { return v  = v  * x ; } \
    inline VEC##4 operator*=(VEC##4 &v , VEC1    x ) { return v  = v  * x ; } \
    inline VEC##2 operator/=(VEC##2 &v , VEC1    x ) { return v  = v  / x ; } \
    inline VEC##3 operator/=(VEC##3 &v , VEC1    x ) { return v  = v  / x ; } \
    inline VEC##4 operator/=(VEC##4 &v , VEC1    x ) { return v  = v  / x ; } \

    MACRO_VEC(float,  vec, v * (1.0f / x))
    MACRO_VEC(int  , ivec, v / x         )

    inline float dot      (vec2 v1, vec2 v2) { return      v1.x * v2.x + v1.y * v2.y                             ; }
    inline float dot      (vec3 v1, vec3 v2) { return      v1.x * v2.x + v1.y * v2.y + v1.z * v2.z               ; }
    inline float dot      (vec4 v1, vec4 v2) { return      v1.x * v2.x + v1.y * v2.y + v1.z * v2.z + v1.z * v2.z ; }
    inline float length   (vec2 v          ) { return sqrt(v .x * v .x + v .y * v .y                            ); }
    inline float length   (vec3 v          ) { return sqrt(v .x * v .x + v .y * v .y + v .z * v .z              ); }
    inline float length   (vec4 v          ) { return sqrt(v .x * v .x + v .y * v .y + v .z * v .z + v .z * v .z); }
    inline vec3  normalize(vec3 v) { float Length = length(v); if (Length == 0) return vec3(0, 0, 0); return v / Length; }
}


//****************************************************************************************************
// Color
//****************************************************************************************************
// The reason I separate it from vec3/vec4 is its structure is (r, g, b[, a]) which is different from (x, y, z[, w]).

namespace myengine
{
    inline uint32_t vec4_to_b8g8r8a8_unorm(vec4 unpackedInput);

    struct ColorRGB {
        float r, g, b;
        ColorRGB() = default;
        ColorRGB(float _r, float _g, float _b) : r(_r), g(_g), b(_b) {}

        inline uint32_t c_uint32() {
            return vec4_to_b8g8r8a8_unorm(vec4(b, g, r, 1));
        }
    };

    struct ColorRGBA {
        float r, g, b, a;
        ColorRGBA() = default;
        ColorRGBA(float _r, float _g, float _b, float _a) : r(_r), g(_g), b(_b), a(_a) {}
        ColorRGBA(const ColorRGB &c, float a) : r(c.r), g(c.g), b(c.b), a(a) {}

        inline ColorRGB getRGB() {
            return ColorRGB(r, g, b);
        }
        inline uint32_t c_uint32() {
            return vec4_to_b8g8r8a8_unorm(vec4(b, g, r, a));
        }
    };

    inline ColorRGB  operator+ (ColorRGB   c1, ColorRGB  c2) { return ColorRGB (c1.r + c2.r, c1.g + c2.g, c1.b + c2.b             ); } \
    inline ColorRGBA operator+ (ColorRGBA  c1, ColorRGBA c2) { return ColorRGBA(c1.r + c2.r, c1.g + c2.g, c1.b + c2.b, c1.a + c2.a); } \
    inline ColorRGB  operator- (ColorRGB   c1, ColorRGB  c2) { return ColorRGB (c1.r - c2.r, c1.g - c2.g, c1.b - c2.b             ); } \
    inline ColorRGBA operator- (ColorRGBA  c1, ColorRGBA c2) { return ColorRGBA(c1.r - c2.r, c1.g - c2.g, c1.b - c2.b, c1.a - c2.a); } \
    inline ColorRGB  operator- (ColorRGB   c               ) { return ColorRGB (     - c .r,      - c .g,      - c .b             ); } \
    inline ColorRGBA operator- (ColorRGBA  c               ) { return ColorRGBA(     - c .r,      - c .g,      - c .b,      - c .a); } \
    inline ColorRGB  operator* (float      x , ColorRGB  c ) { return ColorRGB (   x * c .r,    x * c .g,    x * c .b             ); } \
    inline ColorRGBA operator* (float      x , ColorRGBA c ) { return ColorRGBA(   x * c .r,    x * c .g,    x * c .b,    x * c .a); } \
    inline ColorRGB  operator* (ColorRGB   c , float     x ) { return ColorRGB (c .r *    x, c .g *    x, c .b *    x             ); } \
    inline ColorRGBA operator* (ColorRGBA  c , float     x ) { return ColorRGBA(c .r *    x, c .g *    x, c .b *    x,  c.a *    x); } \
    inline ColorRGB  operator/ (ColorRGB   c , float     x ) { return c * (1.0f / x); } \
    inline ColorRGBA operator/ (ColorRGBA  c , float     x ) { return c * (1.0f / x); } \
    inline ColorRGB  operator+=(ColorRGB  &c1, ColorRGB  c2) { return c1 = c1 + c2; } \
    inline ColorRGBA operator+=(ColorRGBA &c1, ColorRGBA c2) { return c1 = c1 + c2; } \
    inline ColorRGB  operator-=(ColorRGB  &c1, ColorRGB  c2) { return c1 = c1 - c2; } \
    inline ColorRGBA operator-=(ColorRGBA &c1, ColorRGBA c2) { return c1 = c1 - c2; } \
    inline ColorRGB  operator*=(ColorRGB  &c , float     x ) { return c  = c  * x ; } \
    inline ColorRGBA operator*=(ColorRGBA &c , float     x ) { return c  = c  * x ; } \
    inline ColorRGB  operator/=(ColorRGB  &c , float     x ) { return c  = c  / x ; } \
    inline ColorRGBA operator/=(ColorRGBA &c , float     x ) { return c  = c  / x ; } \
}