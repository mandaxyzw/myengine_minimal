#pragma once

#include <string>   // std::string


//****************************************************************************************************
// Error Message
//****************************************************************************************************
#if defined(_WIN32)
#define myengine_error(error) \
{ \
    MessageBox(nullptr, error, "myengine-engine error", MB_OK | MB_ICONERROR); \
    __debugbreak(); \
} ((void)0) // There must be ";".

#define myengine_error_nobreak(error) \
{ \
    MessageBox(nullptr, error, "myengine-engine error", MB_OK | MB_ICONERROR); \
} ((void)0) // There must be ";".

#define myengine_error_exit(error) \
{ \
    myengine_error_nobreak(error); \
    exit(1); \
} ((void)0) // There must be ";".
#else
#error Unsupported OS
#endif

// The reason of 'release' is there will be scripting with the release configuration and this will be needed.
#define myengine_assert_release(expression) { \
    if(!(expression)) { \
        myengine_error("!(" #expression ")"); \
    } \
}

//****************************************************************************************************
// String
//****************************************************************************************************
std::string to_lower_copy(const std::string &str);
std::string to_upper_copy(const std::string &str);

//****************************************************************************************************
// Directory
//****************************************************************************************************
std::string currentPath();
std::string pathFolderName(std::string);
std::string binPath(const std::string &projectName);