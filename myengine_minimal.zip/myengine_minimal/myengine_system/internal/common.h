#pragma once

#include <string>   // std::string
#include <vector>   // std::vector
#include <iostream> // std::cout
#include <cctype>   // std::tolower, std::toupper

// internal
#include "myengine_math.h"

//****************************************************************************************************

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))

#ifndef SAFE_FREE
#define SAFE_FREE(p)            { if (p) { free (p);       (p)=nullptr; } }
#endif
#ifndef SAFE_DELETE
#define SAFE_DELETE(p)          { if (p) { delete (p);     (p)=nullptr; } }
#endif
#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p)    { if (p) { delete[] (p);   (p)=nullptr; } }
#endif
#ifndef VK_SAFE_DESTROY
#define VK_SAFE_DESTROY(x, p)   { if (p) { vkDestroy##x(device, (p), nullptr); (p)=nullptr; } }
#endif

// https://stackoverflow.com/questions/3386861/converting-a-variable-name-to-a-string-in-c
#define VARIABLE_TO_STRING(variable) (void(variable), #variable)
#define FUNCTION_TO_STRING(function) (void(&function), #function)
#define METHOD_TO_STRING(className, method) (void(&className::method), #method)
#define TYPE_TO_STRING(type) (void(sizeof(type)), #type)

#include <fstream>

//****************************************************************************************************

#include "imgui.h"
#include "imgui_impl_sdl.h"
#include "imgui_impl_vulkan_edit.h"
#include "imgui_internal.h"


//****************************************************************************************************
// Vulkan
//****************************************************************************************************
#define SDL_MAIN_HANDLED // Tell SDL not to mess with main(). Most of the time, SDL starts with a console application. Avoid the error: unresolved external symbol main referenced in function "int __cdecl invoke_main(void)"
#include <SDL2/SDL.h>
#include <SDL2/SDL_vulkan.h>
#include <vulkan/vulkan.h>

#include "vulkanexamplebase_edit.h" // EDIT: I commented the line #pragma comment(linker, "/subsystem:windows") but before, it didn't accept a console application.
#include "VulkanglTFModel.h"

// Redefine the existing macro to check and display Vulkan return results
#if defined(__ANDROID__)
// No change
#else
#undef VK_CHECK_RESULT
#define VK_CHECK_RESULT(f) {                                                                             \
    VkResult res = (f);                                                                                  \
    if (res != VK_SUCCESS) {                                                                             \
        std::string str = std::string("Fatal : VkResult is \"") + vks::tools::errorString(res) + "\" in " + __FILE__ + " at line " + std::to_string(__LINE__); \
        myengine_error(str.c_str());                                                                          \
    }                                                                                                    \
}
#endif

#ifndef NDEBUG
#define VERIFY(x) assert(x)
#else
#define VERIFY(x) ((void)(x))
#endif

#ifdef _DEBUG // Limitation: The 'validation' variable in vulkanexamplebase.h is independent from this.
#define EMC_VULKAN_DEBUG_REPORT
#endif

VkAllocationCallbacks* vk_getAllocationCallBacks_ptr();


#include "common_base.h"
// Lesson: #include "appbase.h", "gui_kernel.h", ... are not placed here, because they can be frequently modified and that the compilation time becomes very slow because of this common header file.
